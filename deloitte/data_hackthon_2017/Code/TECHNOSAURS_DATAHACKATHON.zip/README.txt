Python libraries need to be installed
Dependency:

1.) Pandas, 
2.) Sklearn,
3.) Numpy,
4.) Keras on Tensorflow
5.) matplotlib

Before running the code. Edit the code and change the value of root_path to the respective directory where we have extracted .csv file both HackathonRound1.csv and DataUpdate_Hackathon.csv

To run the code and generate the sample_submission.csv. Run the code in following order.

1.) final.py

TECHNOSAURS_DATAHACKATHON.csv will be generated into root_path directory.


